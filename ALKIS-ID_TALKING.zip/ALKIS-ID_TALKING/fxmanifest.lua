fx_version 'cerulean'
game 'gta5'

author 'Jonas Baltutis'
description 'Rodomas kalbančiojo ID su tamsiai violetine spalva'
version '1.0.0'

client_script 'voice_indicator.lua'
